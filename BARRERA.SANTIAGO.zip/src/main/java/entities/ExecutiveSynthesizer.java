package entities;

public class ExecutiveSynthesizer implements ISynthesizer {
}
