package entities;

public interface ISynthesizer {
}
