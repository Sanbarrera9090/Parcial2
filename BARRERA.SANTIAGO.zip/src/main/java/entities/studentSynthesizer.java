package entities;

public class studentSynthesizer implements ISynthesizer{
}
